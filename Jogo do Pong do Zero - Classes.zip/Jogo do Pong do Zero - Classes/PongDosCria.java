
// IMPORTANDO ALGUMAS FERRAMENTAS QUE VAMOS USAR PARA FAZER UM JOGO SIMPLES DE PONG
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;

// CRIANDO UM JOGO DE PONG
public class PongDosCria {

    // O LUGAR ONDE NOSSO JOGO COMEÇA
    public static void main(String[] args) {

        // CRIANDO UMA JANELA PARA O JOGO
        GameFrame frame = new GameFrame();

    }
}
